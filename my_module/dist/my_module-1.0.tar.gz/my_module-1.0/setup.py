from distutils.core import setup

setup(
    name='my_module',
    version='1.0',
    py_modules=['format_headers'],
    author='qq1789500304',
    author_email='1789500304@qq.com',
    url='http://www.xiaoxinfeng.com.cn',
    descriptioin='给谷歌浏览器复制的headers添加引号,让爬虫可以直接使用',
)
